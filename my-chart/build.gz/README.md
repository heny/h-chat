### 修改文件并上传

```bash
git add .
git commit -m 'add commit'
git push
```

### 自动部署服务器

```bash
sh delony.sh
sh delony.sh
```