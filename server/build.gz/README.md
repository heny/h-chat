### 启动方式
>已配置热更新，修改文件不需要重启服务

npm run start 



### 部署方式(自己按照自己的方式部署)
npm run upload  // 上传到服务器，并登录服务器
sh delony_server.sh  // 在服务器中执行

之后重启pm2项目